# VRFS Broadcast Studio

Files:
- `index.html` — launcher
- `admin.html` — separate operator/admin panel
- `output.html` — clean broadcast output

## Use
1. Open `admin.html`.
2. Open `output.html` in a separate tab/window.
3. In Output click **Choose Background**.
4. Select the VRFS game window/app in Chrome/Edge's share picker.
5. The game appears as the background.
6. Drag the scoreboard anywhere you want.
7. Use Admin to change names, scores, clock, logos and visibility.

For GitHub Pages, upload all three HTML files and README.md to the repository root. Open `index.html` through the published site.
